# Changelog

All notable changes to this template will be documented in this file.

## [1.0.0] - [2022-03-16]

### Added

- Initial Release
